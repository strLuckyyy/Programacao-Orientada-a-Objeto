Boa noite, desculpas pelo atraso na entrega.

Dando um pouco de contexto: normalmente, eu trabalho em dupla com o Lucas, mas nesta atividade específica, a parceria deveria ser com o Leonardo. No entanto, devido a "diferenças" na nossa abordagem para o funcionamento do código, preferi fazer o trabalho individualmente (o que pessoalmente prefiro, independente da pessoa). Portanto, esta tarefa foi realizada 100% por mim, apesar de não seguir exatamente o pedido.

Vale apontar que, tentei praticar e aprender algumas coisas "novas" durante a atividade, como os match-case e o operador ternário. Ainda tenho bastante a evoluir, mas estou feliz como resultado desse código.


Enfim, a maior parte do funcionamento do sistema está na classe "Acervo", onde se encontra a maior parte do código e onde ocorre a lógica principal.

Na classe "Main", basicamente, temos o menu. Recomendo começar por ela para se guiar no entendimento do código.

A classe "Usuario" possui três blocos principais: um que verifica a possibilidade de locação do livro, outro que devolve o livro, e um terceiro que imprime as informações da estante.

A classe "Livro" possui um único bloco grande, cuja principal função é verificar a disponibilidade do objeto. Em geral, essa classe é mais usada para definir os objetos do tipo livro, então é a que menos possui código.

O código está todo comentado – talvez até em excesso –, pois procurei deixá-lo o mais autoexplicativo possível, tentei também utilizar algumas técnicas de organização de código.


- Abrahão