class Pessoa:
    def __init__(self, nome, idade, altura, qtde_irmaos, endereco):
        self.nome = nome
        self.idade = idade
        self.altura = altura
        self.qtde_irmaos = qtde_irmaos
        self.endereco = endereco

    def imprime_info(self):
        print(f'Nome: {self.nome}')
        print(f'Idade: {self.idade}')
        print(f'Altura: {self.altura}')
        print(f'Quantidade de irmãos: {self.qtde_irmaos}')
        print(f'Endereço: {self.endereco}')

    def is_filho_unico(self):
        if(self.qtde_irmaos <= 0):
            print('Filho(a) único(a)')
        else:
            print('Não é filho(a) único(a)')


def main():
    p1 = Pessoa("Chaves", 90, 1.70, 0, "Barril, 00")
    p2 = Pessoa("Dona Matilde", 87, 1.65, 2, "A Vizinhança, 71")
    p3 = Pessoa("Chiquinha", 80, 1.51, 0, "A Vizinhança, 72")

    p1.imprime_info()
    p1.is_filho_unico()
    print()
    p2.imprime_info()
    p2.is_filho_unico()
    print()
    p3.imprime_info()
    p3.is_filho_unico()


if __name__ == '__main__':
    main()
