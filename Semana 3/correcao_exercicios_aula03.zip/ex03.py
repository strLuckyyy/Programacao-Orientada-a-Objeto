class CalculoIR:
    def __init__(self, nome, ano_nasc, profissao, escolaridade, renda, dependentes):
        self.nome = nome
        self.ano_nasc = ano_nasc
        self.profissao = profissao
        self.escolaridade = escolaridade
        self.renda = renda
        self.dependentes = dependentes

    def retorna_idade(self):
        return 2024 - self.ano_nasc

    def renda_anual(self):
        return 12 * self.renda

    def renda_per_capita_mensal(self):
        return self.renda / self.dependentes

    def retorna_aliquota_maxima(self):
        if(self.renda <= 2259.20):
            return 0.0
        elif(self.renda >= 2259.21 and self.renda <= 2826.65):
            return 0.075
        elif(self.renda >= 2826.66 and self.renda <= 3751.05):
            return 0.15
        elif(self.renda >= 3751.06 and self.renda <= 4664.68):
            return 0.225
        else:
            return 0.275


    def retorna_deducao_aliquota_maxima(self):
        if(self.renda <= 2259.20):
            return 0.0
        elif(self.renda >= 2259.21 and self.renda <= 2826.65):
            return 169.44
        elif(self.renda >= 2826.66 and self.renda <= 3751.05):
            return 381.44
        elif(self.renda >= 3751.06 and self.renda <= 4664.68):
            return 662.77
        else:
            return 896.00

    def calcula_ir_mensal(self):
        return ((self.renda * self.retorna_aliquota_maxima()) -
                self.retorna_deducao_aliquota_maxima)

    def calcula_ir_anual(self):
        return calcula_ir_mensal * 12


def main():
    c = CalculoIR("Ada Lovalace", 1815, "Matemática", "Ensino Superior",
                  20456.89, 4)
    print(f'Renda per capita mensal: {c.renda_per_capita_mensal():.2f}')
    print(f'Valor do imposto anual: {c.calcula_ir_anual()}')


if __name__ == '__main__':
    main()
