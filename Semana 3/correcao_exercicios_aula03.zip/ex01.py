class Retangulo:
    def __init__(self, base, altura):
        self.base = base
        self.altura = altura

    def retorna_base(self):
        return self.base

    def retorna_altura(self):
        return self.altura

    def calcula_area(self):
        return self.base * self.altura


def main():
    r = Retangulo(float(input("Informe a base do retângulo: ")),
                  float(input("Informe a altura do retângulo: ")))
    print(f'Base do retângulo: {r.retorna_base()}')
    print(f'Altura do retângulo: {r.retorna_altura()}')
    print(f'Área do retângulo: {r.calcula_area():.2f}')


if __name__ == "__main__":
    main()
